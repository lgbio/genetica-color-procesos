 library(devtools);document();build_vignettes();install(build_vignettes=T)
