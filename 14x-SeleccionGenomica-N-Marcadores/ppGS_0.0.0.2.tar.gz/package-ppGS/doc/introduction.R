### R code from vignette source 'introduction.Rnw'

