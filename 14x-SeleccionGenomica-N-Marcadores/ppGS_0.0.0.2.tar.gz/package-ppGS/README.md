# ppGS: Parallel Pipeline for Genomic Selection
R package for genomic selection with multiple or single phenotypes. 
