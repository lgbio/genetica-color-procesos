Full datasets for training ClusterCall (see vignette)

