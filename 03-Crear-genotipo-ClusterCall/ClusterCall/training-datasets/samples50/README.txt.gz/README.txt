These datasets are toy examples (subsets of 1000 markers). 
Created only for testing the script

